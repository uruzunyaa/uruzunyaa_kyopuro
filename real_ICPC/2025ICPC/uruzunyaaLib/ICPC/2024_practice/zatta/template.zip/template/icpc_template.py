#1つのデータセットにつき、1回のsolve関数で答える
def solve():
    
    #データセットの終わりなら、1を返す、終了条件を見て修正
    if 0 == 0:
        return 1
    
	#ここに処理を記述
    return 0

while solve()==0:
    pass