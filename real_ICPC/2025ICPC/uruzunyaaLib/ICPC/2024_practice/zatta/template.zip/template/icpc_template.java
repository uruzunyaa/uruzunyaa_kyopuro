import java.util.*;
public class Main {
	static Scanner scan = new Scanner(System.in);

    // １回の入力につき、１回のsolve関数を使う
    public static int solve() {
		//終了条件になるような変数を読み込み。
		
        if (/*入力の終わりの条件を記述 */)return 1;
        
		//ここにプログラムを記述
        return 0;
    }

    public static void main(String[] args){
        while (solve()==0);
    }
}

